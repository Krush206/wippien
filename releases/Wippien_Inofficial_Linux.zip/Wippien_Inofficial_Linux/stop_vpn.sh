#!/bin/bash
sudo killall ld-linux.so.2