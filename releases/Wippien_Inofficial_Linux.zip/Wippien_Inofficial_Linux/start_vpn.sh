#!/bin/bash
# Author: Daniel G., S1510306010
#	  giri@nwrk.biz
# Date: 5.1.2017

#Working DIR
DIR=$(pwd)

#Config file lesen
USERNAME=$(grep username ./config/wippien.conf | cut -d ' ' -f 2)
PASSWORD=$(grep password ./config/wippien.conf | cut -d ' ' -f 2)

#Ordner mit allen Abhängigkeiten.
LIBRARY_PATH=$DIR/lib

#Displays mittels mitgelieferten dynamischen Linker Starten.
#--library-path erzwingt 'lib' als Pfad für die benötigten
#i386 Libraries.
sudo su -c "$LIBRARY_PATH/ld-linux.so.2 --library-path $LIBRARY_PATH $DIR/wiptun &> $DIR/logs/interface.log &"
$LIBRARY_PATH/ld-linux.so.2 --library-path $LIBRARY_PATH $DIR/wipclnt $USERNAME $PASSWORD &> $DIR/logs/client.log &
